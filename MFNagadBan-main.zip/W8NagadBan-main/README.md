## Install Termux Commands

Termux-Packages-Install

```
pkg update -y
```
```
pkg upgrade -y
```
```
pkg install git -y
```


--Clone this repository--

```
git clone https://github.com/MrAsfard/MFNagadBan
```
```
cd MFNagadBan
```
```
ls
```

```
python MFNagadBan.py
```

ONE CLICK INSTALL
```
pkg update -y && pkg upgrade -y && pkg install git python -y && git clone https://github.com/MrAsfard/MFNagadBan && cd MFNagadBan && pip install -r requirements.txt && python MFNagadBan.py
```


Join  Our Telegram Channel:> https://t.me/Mr_Asfard_sir
